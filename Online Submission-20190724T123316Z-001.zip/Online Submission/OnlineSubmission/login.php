<?php 

include'handler/dbcon.php';

if (isset($_POST['login'])) {
	$email=filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);//sanitizs email

	$_SESSION['email']= $email;//store email into session variable
	$password=md5($_POST['password']);

	$check_database_query=mysqli_query($con,"SELECT * FROM student WHERE email='$email'AND password='$password'");
	$check_login_query=mysqli_num_rows($check_database_query);

	if($check_login_query==1){
		$row = mysqli_fetch_array($check_database_query);
		$fname=$row['fname'];
$user_closed_query=mysqli_query($con,"SELECT*FROM student WHERE email ='$email' AND user_closed='yes'");
if(mysqli_num_rows($user_closed_query)==1){
	$reopen_account=mysqli_query($con,"UPDATE student SET user_closed='no' WHERE email='$email'");
}

		$_SESSION['fname']=$fname;
		header("Location:home.php");
		exit();

	}
	else{
		$error="email or password was incorrect<br>";
	}

}




?>




 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta http-equiv="X-UA-Compatible" content="IE=edge">
 	<title>login page</title>
 	<link rel="stylesheet" href="">
 </head>
 <body>
 	<form action="reg.php" method="post" accept-charset="utf-8">
 		email:
 	<input type="email" name="email" placeholder="email" required="">
 	<br>
 	password:
 	<input type="password" name="password" placeholder="password" required="">
 	<br>
 	<input type="submit" name="login" value="login">
 	
 		
 	</form>

 	
 </body>
 </html>
