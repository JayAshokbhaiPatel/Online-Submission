<?php
include'handler/dbcon.php';
//include'login.php';

//$error_array= array();//hold error msg
$day="";
$month="";
$year="";

if (isset($_POST['submit'])) {

	$prn=mysqli_real_escape_string($con,$_POST['prn']);
		$_SESSION['prn']=$prn;//stores prn in session

		//first name
		$fname=mysqli_real_escape_string($con,$_POST['fname']);
		$fname=str_replace(' ','',$fname);
		$fname=ucfirst(strtolower($fname));
		$_SESSION['fname']=$fname;

		$mname=mysqli_real_escape_string($con,$_POST['mname']);
		$mname=str_replace(' ','',$mname);
		$mname=ucfirst(strtolower($mname));
		$_SESSION['mname']=$mname;


		//last name
		$lname=mysqli_real_escape_string($con,$_POST['lname']);
		$lname=str_replace(' ','',$lname);
		$lname=ucfirst(strtolower($lname));
		$_SESSION['lname']=$lname;

		$em=mysqli_real_escape_string($con,$_POST['email']);
		$em=str_replace(' ','',$em);
		$em=ucfirst(strtolower($em));
		$_SESSION['email']=$em;

		$em2=mysqli_real_escape_string($con,$_POST['email2']);
		$em2=str_replace(' ','',$em2);
		$em2=ucfirst(strtolower($em2));
		$_SESSION['email2']=$em2;
		$dob=mysqli_real_escape_string($con,$_POST['dob']);
		$dob = date("Y-m-d",strtotime($_POST['dob']));

		$add=mysqli_real_escape_string($con,$_POST['add']);

		$city=mysqli_real_escape_string($con,$_POST['city']);
		$gender=mysqli_real_escape_string($con,$_POST['gender']);
		$pwd=mysqli_real_escape_string($con,$_POST['password']);
		$pwd2=mysqli_real_escape_string($con,$_POST['password2']);

		$date=Date("Y-m-d");

		if ($em==$em2) {
		//match the email
			if(filter_var($em, FILTER_VALIDATE_EMAIL) ) {

				$em=filter_var($em,FILTER_VALIDATE_EMAIL);

				//check if email already exists
				$e_check=mysqli_query($con,"SELECT email FROM student WHERE email='$em'");

				//count the number of rows returned
				$num_rows=mysqli_num_rows($e_check);

				if($num_rows>0){
					//array_push($error_array, "email already in use<br>");
					$e_error= "email already in use<br>";
					//header("location: ../reg.php?reg=already");
				}
			}
			else
			{
			//array_push($error_array,"email already in use<br>");
				$e_error= "invalid email format<br>";
				//header("location: ../reg.php?reg=invalid");
				//exit();
			}
		}

		else
		{
			//array_push($error_array,"email don't match<br>");
			$e_error=  "email dont match<br>";
			//header("location: ../reg.php?reg=dont match");
			//echo "email dont match<br>";
			//exit();

		}

		if (strlen($fname)>25|| strlen($fname) <2){
			$f_error=  "your first name must be between 2 and 25 characters<br>";
		}
		

		if (strlen($lname)>25|| strlen($lname) <2){
			$l_error= "your last name must be between 2 and 25 characters<br>";
		}
		

		if ($pwd!=$pwd2) {
			$p_error="your password do not match<br>";

		}
		else{
			if (preg_match('/[^A-Za-z0-9]/', $pwd)) {
				$p_error= "your password  only contain characters or numbers and symbol<br>";

			}
		}
		if (strlen($pwd)>30|| strlen($pwd)<5) {

			$p_error= "your password must be between 5 to 30 characters<br>";
		}
		//prn validation
		if (strlen($prn)<13||strlen($prn)>15) {
			$pr_error="pleace enter valid prn number";

			
		}
		
		
		





		if (empty($error)|| empty($pr_error)|| empty($e_error)|| empty($p_error)|| empty($f_error)|| empty($l_error) ) {
			 //$pwd => password_hash($pwd, PASSWORD_BCRYPT, [12]);
			 //'password'=> password_hash($pwd, PASSWORD_BCRYPT, [12]);
			$pwd=md5($pwd);

			$query=mysqli_query($con,"INSERT INTO student VALUES('','$prn','$fname','$lname','$em','$dob','$add','$city','$gender','$pwd','$date')");

			$cmsg="<span style='color:#08FA24;'>go ahead and login</span><br>";

			$_SESSION['fname']=""; 
			$_SESSION['mname']="";
			$_SESSION['lname']="";
			$_SESSION['email']="";
			$_SESSION['email2']="";
			$_SESSION['RRN']="";	
			$_SESSION['password']="";
			$_SESSION['mname']="";

		}
	}
	?>


	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<!--<meta http-equiv="refresh" content="3"; url=reg.php>-->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<script src="js/Validation.js"></script>

		
		

		<script>
			function validation()
			{
				if (isNaN(form1.phone.value)) {
					alert("invalid phone number");
					form1.phone.focus();
					return false;
				}
				if ((form1.phone.value).length < 10) {
					alert("phone number should be minimum 10 digits");
					form1.phone.focus();
					return false;
				}
				return true;
			}

		</script>






		<title>Registration</title>

	</head>
	<body>
		<center><h1>Registration FORM </h1></center>
		<!--<div class="container">-->
			<div class="row-main">
				<div class="main-login main-center">
					
					<form action="" name="frm" method="POST" onsubmit="return validation()" enctype="multipart/form-data">
						<div class="form-group">
							<div class=" col-sm-4 ">
								FirstName:
								<input type="text" name="fname" id="fname" placeholder="FirstName" class="form-control" value="

								<?php if (isset($_SESSION['fname'])) {
									echo $_SESSION['fname'];
								} ?>" required> 
								<br>

								<span style="color: red;">
									<?php if (isset($f_error)) {echo $f_error;}?>
								</span>
							</div>



							<br>

							<div class="col-sm-4">
								MiddleName:
								<input type="text" name="mname" id="mname" placeholder="MiddleName" class="form-control" value="
								<?php if (isset($_SESSION['mname'])) {
									echo $_SESSION['mname'];
								} ?>" required>
								<br><br>
								<span style="color: red;">
									<?php 

									if (isset($error)) {
										echo $error;

									}

									?> 
								</span>
							</div>

							<div class=" col-auto">
								LastName:
								<input type="text" name="lname" id="lname" placeholder="LastName" class="form-control" value="
								<?php if (isset($_SESSION['lname'])) {
									echo $_SESSION['lname'];
								} ?>" required > 
								<br><br>
								<span style="color: red;">
									<?php if (isset($l_error)) {echo $l_error;}?> 
								</span>
							</div>
						</div>

						Gender:<input type="radio" name="gender" id="gender" value="male"> Male
						<input type="radio" name="gender" id="gender" value="female"> Female
						<br><br>

						Enter date of birth:
						<input type="date" name="dob" id="dob" size="10"
						maxlength="10" placeholder="DD-MM-YYYY">
						DD-MM-YYYY
						<?php  ?>

						<br>
						<br>
						Contact No
						<input  type="tel" name="phone" id="phone" maxlength="10">
						<br><br>



						<label>Email address</label>
						<input type="email" name="email" id="email"  placeholder="Enter email"
						value="

						<?php if (isset($_SESSION['email'])) {
							echo $_SESSION['email'];
						} ?> " required> 
						<br><br>

						confirm E-mail:<input type="email" name="email2" id="email2" placeholder="confirm E-mail" value="
						<?php if (isset($_SESSION['email2'])) {
							echo $_SESSION['email2'];
						} ?> " required> 
						<br>
						<br>
						<span style="color: red;">
							<?php 
							if (isset($e_error)) {
								echo $e_error;

							}



							?>
						</span>
						<br>



						PRN:<input type="text" name="prn" id="prn" class="form-control-md" placeholder="PRN"  maxlength="14" required><br><br>
						<span style="color: red;">
							<?php 

							if (isset($pr_error)) {
								echo $pr_error;

							}?>
						</span>
						<br>



						<label >Address:</label>
						<textarea name="add" id="add"></textarea>
						<br>
						<br>



						<label>Select City</label>
						<select name="city">
							<option name="vadodara">vadodara</option>
							<option name="Ahmedabad">Ahmedabad</option>
							<option name=" Surat">Surat</option>
							<option name="bharuch">bharuch</option>
							<option name="Rajkot" >Rajkot</option>
						</select>


						<br>
						<br>

						Year:<select name="year" required>
							<option value="sy" name="sy" selected="">SY</option>
							<option value="ty" name="ty">TY</option>

						</select>
						<br><br>


						<label>family information</label>

						<br><br>




						Password:<input type="password" name="password" id="pwd" placeholder="Password" required>
						<br><br>

						confirm Password:<input type="password" name="password2" id="pwd2" placeholder="confirm Password" required>
						<br><br>
						<span style="color: red;">
							<?php 
							if (isset($p_error)) {
								echo $p_error;
							}

							?>

						</span>

						<?php ?>

						<input type="submit" name="submit" value="register">&nbsp;&nbsp;
						<input name="reset" type="reset" id="reset" value="Reset">&nbsp;&nbsp;
						<input name="close" type="button" id="close" value="Close">&nbsp;&nbsp;
						<br>
						<br>


						<?php $cmsg = "<span style='color:#08FA24;'>go ahead and login</span> <br>";
						?>







					</form>
				</div>
			</div>
		</div>

		<!-- Optional JavaScript -->


		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
	</body>
	</html>



