<?php 
include 'handler/dbconn.php';
$db=new DATABASE;
 ?>
 <h3>request for new password</h3>
 <hr>
 <form action="" method="post">
 	<input type="email" name="recovery_email" placeholder="enter your email" required=""><br><br>
 	<input type="submit" name="lost_password" value="request new password">
 	
 </form>
 <?php 
if (isset($_POST['lost_password'])) {
	$email=mysqli_real_escape_string($db->con,$_POST['recovery_email']);
	$sql=" SELECT prn FROM student WHERE email='$email' LIMIT 1"; $query=mysqli_query($db->con,$sql);
	if (mysqli_num_rows($query)==1) {
		$row=mysqli_fetch_array($query);
		
	}
}
  ?>